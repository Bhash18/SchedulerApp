/**
 * 
 */
package com.scheduler.model;

/**
 * 
 */
public record Person(String name, String email) {

}
