/**
 * 
 */
package com.scheduler.service;

import com.scheduler.model.*;
import com.scheduler.store.*;
import java.util.*;

/**
 * Service to manage person creation and lookup
 */
public class PersonService {
    private final InMemoryStore store;

    public PersonService(InMemoryStore store) {
        this.store = store;
    }

    public Person createPerson(String name, String email) {
        if (store.personByEmail.containsKey(email)) {
            throw new IllegalArgumentException("Email already exists: " + email);
        }
        Person person = new Person(name, email);
        store.personByEmail.put(email, person);
        store.personMeetingSlots.put(email, new HashSet<>());
        return person;
    }

    public Optional<Person> getPerson(String email) {
        return Optional.ofNullable(store.personByEmail.get(email));
    }
}