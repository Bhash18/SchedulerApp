/**
 * 
 */
package com.scheduler.service;

import com.scheduler.model.*;
import com.scheduler.store.*;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Service to fetch schedules and suggest available time slots
 */
public class ScheduleService {
    private final InMemoryStore store;

    public ScheduleService(InMemoryStore store) {
        this.store = store;
    }

    public List<Meeting> getSchedule(String email) {
        return store.meetings.stream()
            .filter(m -> m.attendees().stream().anyMatch(p -> p.email().equals(email)))
            .sorted(Comparator.comparing(Meeting::startTime))
            .toList();
    }

    public List<LocalDateTime> suggestSlots(List<String> participantEmails) {
        Set<LocalDateTime> occupied = new HashSet<>();

        for (String email : participantEmails) {
            Set<LocalDateTime> times = store.personMeetingSlots.getOrDefault(email, Set.of());
            occupied.addAll(times);
        }

        List<LocalDateTime> available = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now().withMinute(0).withSecond(0).plusHours(1);
        LocalDateTime end = now.plusDays(7);

        while (now.isBefore(end)) {
            if (!occupied.contains(now)) available.add(now);
            now = now.plusHours(1);
        }
        return available;
    }
}