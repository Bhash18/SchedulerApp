/**
 * 
 */
package com.scheduler;

import java.time.LocalDateTime;
import java.util.List;

import com.scheduler.service.MeetingService;
import com.scheduler.service.PersonService;
import com.scheduler.service.ScheduleService;
import com.scheduler.store.InMemoryStore;

/**
 * 
 */
public class SchedulerApp {
	
	public static void main(String[] args) {
        InMemoryStore store = new InMemoryStore();
        PersonService personService = new PersonService(store);
        MeetingService meetingService = new MeetingService(store);
        ScheduleService scheduleService = new ScheduleService(store);

        personService.createPerson("abc", "abc@test.com");
        personService.createPerson("def", "def@test.com");
        personService.createPerson("xyz", "xyz@test.com");

        LocalDateTime nextHour = LocalDateTime.now().withMinute(0).withSecond(0).plusHours(1);
        meetingService.createMeeting(nextHour, List.of("abc@test.com", "def@test.com"));

        System.out.println("\n abc's Schedule:");
        scheduleService.getSchedule("abc@test.com").forEach(System.out::println);

        System.out.println("\nSuggested slots for abc and xyz:");
        scheduleService.suggestSlots(List.of("abc@test.com", "xyz@test.com")).stream()
            .limit(5)
            .forEach(System.out::println);
    }

}
