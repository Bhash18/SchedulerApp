/**
 * 
 */
package com.scheduler.service;

import com.scheduler.model.*;
import com.scheduler.store.*;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Service to manage meeting creation with conflict detection
 */
public class MeetingService {
    private final InMemoryStore store;

    public MeetingService(InMemoryStore store) {
        this.store = store;
    }

    public Meeting createMeeting(LocalDateTime startTime, List<String> participantEmails) {
        if (startTime.getMinute() != 0 || startTime.getSecond() != 0) {
            throw new IllegalArgumentException("Meeting must start on the hour");
        }

        Set<Person> attendees = new HashSet<>();
        for (String email : participantEmails) {
            Person person = store.personByEmail.get(email);
            if (person == null) throw new IllegalArgumentException("Person not found: " + email);

            Set<LocalDateTime> bookedSlots = store.personMeetingSlots.get(email);
            if (bookedSlots.contains(startTime)) {
                throw new IllegalStateException("Conflict for: " + email);
            }
            attendees.add(person);
        }

        Meeting meeting = new Meeting(UUID.randomUUID(), startTime, attendees);
        store.meetings.add(meeting);
        for (Person p : attendees) {
            store.personMeetingSlots.get(p.email()).add(startTime);
        }
        return meeting;
    }
}
