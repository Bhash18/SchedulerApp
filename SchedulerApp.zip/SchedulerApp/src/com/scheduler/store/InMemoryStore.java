/**
 * 
 */
package com.scheduler.store;

import com.scheduler.model.*;

import java.time.LocalDateTime;
import java.util.*;

/**
 * In-memory data store simulating a repository
 */
public class InMemoryStore {
    public Map<String, Person> personByEmail = new HashMap<>();
    public List<Meeting> meetings = new ArrayList<>();
    public Map<String, Set<LocalDateTime>> personMeetingSlots = new HashMap<>();
}
