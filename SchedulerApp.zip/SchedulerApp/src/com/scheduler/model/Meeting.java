/**
 * 
 */
package com.scheduler.model;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 
 */
public record Meeting(UUID id, LocalDateTime startTime, Set<Person> attendees) {
    @Override
    public String toString() {
        return "Meeting at " + startTime + " with " +
                attendees.stream().map(Person::name).collect(Collectors.joining(", "));
    }
}
